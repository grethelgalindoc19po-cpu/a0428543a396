# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(throughput-bench src/throughput-bench.cpp)
set_property(TARGET throughput-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(throughput-bench lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(feature-flags-matrix src/feature-flags-matrix.cpp)
set_property(TARGET feature-flags-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(feature-flags-matrix lionss pthread)

add_executable(api-tests src/api-tests.cpp)
set_property(TARGET api-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(api-tests lionss pthread)

add_executable(fetchcontent-check src/fetchcontent-check.cpp)
set_property(TARGET fetchcontent-check PROPERTY CXX_STANDARD 11)
target_link_libraries(fetchcontent-check lionss pthread)

add_executable(package-apk src/package-apk.cpp)
set_property(TARGET package-apk PROPERTY CXX_STANDARD 11)
target_link_libraries(package-apk lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(misra-check src/misra-check.cpp)
set_property(TARGET misra-check PROPERTY CXX_STANDARD 11)
target_link_libraries(misra-check lionss pthread)

add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(unicode-tests src/unicode-tests.cpp)
set_property(TARGET unicode-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unicode-tests lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

