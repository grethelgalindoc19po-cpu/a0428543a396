// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("llvm cov\n", stdout);
  return lionss_run_workload("llvm-cov");
}
