// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("negative tests\n", stdout);
  return lionss_run_workload("negative-tests");
}
