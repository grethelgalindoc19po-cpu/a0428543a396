// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("feature flags matrix\n", stdout);
  return lionss_run_workload("feature-flags-matrix");
}
