// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("header guards"); }
int main(){
  announce();
  return lionss_run_workload("header-guards");
}
